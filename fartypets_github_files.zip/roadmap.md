# Fartypets Roadmap

## Phase 1 - Stealth Launch
- Launch directly on Raydium
- Lock liquidity
- Revoke mint authority
- Build core community

## Phase 2 - Foundation
- Apply to CoinGecko, CoinMarketCap
- Launch social media campaigns
- Start DEXTools marketing
- NFT teaser campaign

## Phase 3 - Expansion
- Hit $1M market cap
- Secure major partnerships
- Launch influencer-backed memes
- Surprise utility reveal

## Phase 4 - Full Send
- Reach $10M market cap
- Deploy 30M marketing fund
- Tier-1 CEX listings
- Meme domination
