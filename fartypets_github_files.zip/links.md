# Fartypets Official Links

- Website: https://fartypets.io
- Twitter: https://x.com/FARTYPETSonSol
- Telegram: https://t.me/FARTYPETSONSOL
- GitHub: https://github.com/Fartypets/ftp
