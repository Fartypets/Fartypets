# Fartypets (FTP)

Fartypets is the wildest meme coin on Solana – inspired by hilariously silly pets from the book by Adam Wallace & James Hart.

## 🔥 Why FTP?

- Launched directly on Raydium
- Liquidity provided by team (not just hype)
- Mint authority revoked
- Locked liquidity
- No insider dumping
- Fully community-driven
- Real marketing plan & roadmap
- Built to be the next viral 1000x memecoin

## 📈 Roadmap Highlights

- ✅ Launch on Raydium
- ✅ Lock liquidity
- ✅ Get listed on major trackers (CoinMarketCap, CoinGecko)
- 🔜 Reach $1M Market Cap
- 🔜 Massive marketing push at $10M MC
- 🔜 Tier-1 exchange listing

## 🧠 Smart Contract

Coming soon – FTP is native SPL token on Solana.

## 🌐 Official Links

- Website: https://fartypets.io  
- Twitter: https://x.com/FARTYPETSonSol  
- Telegram: https://t.me/FARTYPETSONSOL  
- GitHub: https://github.com/Fartypets/ftp  

## 📩 Contact

For partnership or listing inquiries, please reach out via X or Telegram.
